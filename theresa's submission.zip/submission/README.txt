### Links to Hosted static website

1. Static url: http://my-11560758578-bucket.s3-website-us-east-1.amazonaws.com
2. Cloudfront url: https://d16zrphzil2ms4.cloudfront.net
3. Bucket path url: https://my-11560758578-bucket.s3.amazonaws.com/index.html
